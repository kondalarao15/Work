/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function() {
    //alert("hii");
    var specialBox = document.getElementById('ActivityBoxOverlay');
    if(specialBox.style.display == "block"){       
        specialBox.style.display = "none";         
    } else {
        specialBox.style.display = "block";      
    }
    // Initialize the plugin    
    $('#Activity_popup').popup(      
        );
    
});
$(document).ready(function() {
    //alert("hii");
    var specialBox = document.getElementById('ActivityEditBoxOverlay');
    if(specialBox.style.display == "block"){       
        specialBox.style.display = "none";         
    } else {
        specialBox.style.display = "block";      
    }
    // Initialize the plugin    
    $('#ActivityEdit_popup').popup(      
        );
    
});

function showActivityDetails(consultId){
    //alert("consultId---"+consultId);
    
        //if(activityFormValid()){
     var url='recruitment/consultant/activityDetails.action?consult_id='+consultId;  
    // var url='../../general/activityDetails.action';
    //var url='../consultant/getConsultantActivity.action';
   // var url='../consultant/getConsultActivitybyActivity.action';
        var req=initRequest(url);
        req.onreadystatechange = function() {
            if (req.readyState == 4 && req.status == 200) {
                
               //alert("-->"+req.responseText);
               populateActivityTable(req.responseText);
          }       
        };  
       req.open("GET",url,"true");
       req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
       req.send(null);
       // }
   return false;
}
/*function populateActivityTable(response){
      alert(response);  
    var activityList=response.split("^");
    

    var table = document.getElementById("consult-activity");
    for(var i = table.rows.length - 1; i > 0; i--)
    {
        table.deleteRow(i);
    }
    for(var i=0;i<activityList.length-1;i++){     
       
        var Values=activityList[i].split("|");
        {  
            alert(Values[0]);                                             
            alert(Values[1]);
            alert(Values[2]);
            alert(Values[3]);
            alert(Values[4]);
            var activity_row = $("</tr>")
            $("#consult-activity").append(activity_row); //this will append tr element to table... keep its reference for a while since we will add cels into it
            activity_row.append($('<td><a href="" class="activityedit_popup_open" onclick=" showeditoverlayDetails('+Values[0]+');" > ' + Values[1] + "</td>"));
            activity_row.append($("<td>" + Values[2] + "</td>"));
            activity_row.append($("<td>" + Values[3] + "</td>"));
            activity_row.append($("<td>" + Values[4] + "</td>"));
            activity_row.append($("<td>" + Values[5] + "</td>"));
                 
        }
    }

   
    pager.init();     
    pager.showPageNav('pager', 'pageNavPosition'); 
    pager.showPage(1);
}*/

function activityFormValid(){
   
   //alert("hi");
    
    var skill_name= $("#s_name").val();
    var skill_rate= $("#s_rate").val();
    var comments=$("#s_comments").val();
    
  
    
    if(skill_name=="" || skill_name==null){
        $("error").html(" <b><font color='red'>Field is Required</font></b>.");
        $("#s_name").css("border","1px solid red");
        return false;
    }
       
    if((skill_rate>10 || skill_rate < 0) || (skill_rate=="" || skill_rate==null) ) 
    {
        $("error").html(" <b><font color='red'>skillrate must be in between 0 to 10</font></b>.");
        $("#s_rate").css("border","1px solid red");
        return false;
    }
    else
    {
        $("error").html("");
        $("#s_name").css("border", "1px solid #3BB9FF");
        $("#s_rate").css("border", "1px solid #3BB9FF");
        return true;
    }
}
function actNamevalidation(){
   // alert("hi");
    document.forms["activityFrm"].reset();
   // alert("hi");
   return false;
}

function populateActivityOverlay(actid){
    //alert("populateActivityOverlay"+actid);
    $("errorActivityUpdate").html(" ");
    //var tet=document.getElementById("actId").value;
    //var val_fromleave= $("#testconsultAct").val();
   // alert("tet"+tet.valueOf());
   //alert('hiii'+val_fromleave);
   //alert("hi---"+actid);
   //(document).getElementById('forgotEmailId').value
    //var activityid=document.getElementById('testconsultAct');
       // document.getElementById("ActivityId").value;
    //var activityid=3;
   // alert('hiiii');../consultant
   // alert("activityid === "+activityid);activityId
    var url='../consultant/getConsultActivitybyActivity.action?activityId='+actid;
    var myurl='<a href='+url+'>';
      //alert("---->Url"+myurl);
      //alert("url"+url);
    var req=initRequest(url);
    req.onreadystatechange = function() {
        //alert("onready state..");
        if (req.readyState == 4) {
            if (req.status == 200) {
                //alert("req success.."+req.responseText);
                populateActivityoverlayDetails(req.responseText);
            } 
            
        }
    };
    req.open("GET",url,"true");
    req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    req.send(null);
}

function populateActivityoverlayDetails(response)
{
    //alert("------------->response overlay"+response);
    var add=response.split("|");
    //alert("add---->"+add);
    //alert("activityID value"+add[0]);
    //for(var i=0;i<add.length-1;i++){        
        
                
            document.getElementById("Activity_name").value=add[1];
            document.getElementById("activityType").value=add[2];
            document.getElementById("Activity_status").value=add[6];
            
            //document.getElementById("skill_name").value=Values[1];
            document.getElementById("Activity_desc").value=add[4];
            document.getElementById("Activity_comments").value=add[5];
            document.getElementById("Activity_Id").value=add[0];
                  
        
    //}
}

function initRequest(url) {
    if (window.XMLHttpRequest) {
        return new XMLHttpRequest();
    }
    else
    if (window.ActiveXObject) {
        isIE = true;
        return new ActiveXObject("Microsoft.XMLHTTP");
    }    
}
 function populateActivityTable(response)
{
   
    var activityList=response.split("^");
   //alert("eduList is---->"+activityList);
   
    var RecordsData ='<table id="consult_activity" class="responsive CSSTable_task" border="5"cell-spacing="2">\n\
                <tr><th>Activity Name</th><th>Activity Status</th>\n\
                <th >Activity Type</th><th >Created By</th><th>Description</th></tr>';
    for(var i=0;i<activityList.length-1;i++){        
        var Values=activityList[i].split("|");
        {  
                                                         
            
//            RecordsData = RecordsData+'<tr><td><a href="" class="notes_popup_open" onclick=" showNotesOverlayDetails('+Values[0]+','+Values[1]+');" >'+Values[2]+'</td></a>'+
//            '<td>'+Values[3]+'</td>'+  <th>Created by</th>
//            '<td>'+Values[4]+'</td></tr>'
//            alert("val---"+Values[3]);
            RecordsData = RecordsData+'<tr><td><s:url class="ActivityEdit_popup_open" action="../getConsultActivitybyActivity.action"><s:param name="activityid"></s:param></s:url>'+
                        '<a onclick="populateActivityOverlay('+Values[0]+')" class="ActivityEdit_popup_open" href="../getConsultActivitybyActivity.action" >'+Values[1]+'</td></a>'+
                        '<td>'+Values[9]+'</td>'+//status
                        '<td>'+Values[4]+'</td>'+//type
                        '<td>'+Values[6]+'</td>'+//created by
                        //'<td>'+Values[5]+'</td>'+//created by
                        //'<td>'+Values[6]+'</td>'+
                        '<td>'+Values[7]+'</td></tr>'; //desc                 
        }
    }
    
    RecordsData=RecordsData+ '</table>';    
    consult_activity.innerHTML=RecordsData;
    
    pager.init(); 
    pager.showPageNav('pager', 'pageNavPosition'); 
    pager.showPage(1);

}

function addConsultActivity(){
   // alert("AddConsultActivityDetails");
    removeActivityResultMessageAll();
    var consultId=$("#consultId").val();
    var activityId=$("#add_Activity_Id").val();
    var activityName=$("#add_Activity_name").val();
    var activityStatus=$("#add_Activity_status").val();
    var activityType=$("#add_activityType").val();
    var activityDesc=$("#add_Activity_desc").val();
    var activityComments=$("#add_Activity_comments").val();
    if(addActivityValidate()){
    var url='../consultant/addNewActivity.action?activityName='+activityName+'&activityStatus='+activityStatus+'&activityType='+activityType+'&activityDesc='+activityDesc+'&activityComments='+activityComments+'&consult_id='+consultId;
   //alert("---->"+url);
   var req=activityRequest(url);
        // var req=initRequest(url);activityId='+activityId+'&
         //alert(req.responseText)
        req.onreadystatechange = function() {
             
            if (req.readyState == 4) {
                if (req.status == 200) {
                    //alert("welcome")
                    //alert(req.responseText)
                    $("errorActivityUpdate").html(" <b><font color='green'>Activity Added Successfully.</font></b>");
                    document.forms["activityAddForm"].reset();
                    showActivityDetails(consultId);
                    //populateActivityTable(req.responseText);
                }
           } 
            else{
             //alert("error");
             //alert("=====>>>"+req.readyState);
            //  alert("=====>>>"+req.status);
            //alert("error");
            }
            
        
        };
        req.open("GET",url,"true");
        req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
        req.send(null);
    }
    return false;
}
function editConsultActivityDetails(){
    
    
   //alert("editConsultActivityDetails");
   
    var activityId=$("#Activity_Id").val();
    var activityName=$("#Activity_name").val();
    var activityStatus=$("#Activity_status").val();
    var activityType=$("#activityType").val();
    var activityDesc=$("#Activity_desc").val();
    var activityComments=$("#Activity_comments").val();
    var consultId=$("#consultId").val();
    
    //alert(activityId+"--"+activityName+"--"+activityStatus+"--"+activityType+"---"+"---"+activityDesc+"---"+activityComments);
    /*var userid=$("#userid").val();
    var usr_edu_id=$("#usr_edu_id").val();
    var edu_qualification=$("#edu_qualification").val();
    var edu_university=$("#edu_university").val();
    var edu_institution=$("#edu_institution").val();
    var edu_start_year=$("#edu_start_year").val();
    var edu_end_year=$("#edu_end_year").val();
    var edu_percentage=$("#edu_percentage").val();
    var edu_specialization=$("#edu_specialization").val();*/
    
    // alert("--------------------->"+edu_start_year);  
    if(editActivityValidate()){
        
        //var url='../general/UpdateQualificationDetails.action?userid='+ userid +'&usr_edu_id='+ usr_edu_id +'&qualification='+ edu_qualification +'&university='+edu_university +'&institution=' +edu_institution +'&start_year='+ edu_start_year +'&end_year='+ edu_end_year +'&percentage='+ edu_percentage +'&specialization=' +edu_specialization ;
        var url='../consultant/editActivity.action?activityId='+activityId+'&activityName='+activityName+'&activityStatus='+activityStatus+'&activityType='+activityType+'&activityDesc='+activityDesc+'&activityComments='+activityComments;
        //alert("percent"+url);
        
        var req=activityRequest(url);
        // var req=initRequest(url);
         //alert(req.responseText)
        req.onreadystatechange = function() {
             
            if (req.readyState == 4) {
                if (req.status == 200) {
                    //alert("welcome")
                    //alert(req.responseText)
                    $("errorActivityUpdate").html(" <b><font color='green'>Activity successfully Updated.</font></b>");
                     document.forms["activityForm"].reset(); 
                    showActivityDetails(consultId);
                    //populateActivityTable(req.responseText);
                }
           } 
            else{
             //alert("error");
             //alert("=====>>>"+req.readyState);
            //  alert("=====>>>"+req.status);
            //alert("error");
            }
            
        
        };
        req.open("GET",url,"true");
        req.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
        req.send(null);
    }
    return false;
}
function activityRequest(url) {
    if (window.XMLHttpRequest) {
        return new XMLHttpRequest();
    }
    else
    if (window.ActiveXObject) {
        isIE = true;
        return new ActiveXObject("Microsoft.XMLHTTP");
    }    
}

function removeActivityResultMessage(){
    //alert("hi");
    //$("EditSkillOverlayResult").html(" ");
    //$("addSkillOverlayResult").html(" ");
    $("errorActivityUpdate").html(" ");
    //$("errorEduAdd").html(" ");
    //$("error").html(" ");
    $("#charNum").text(" ");
    $("#Activity_Id").text(" ");
     $("#add_Activity_name").css("border", "1px solid #3BB9FF");
     $("#add_Activity_status").css("border", "1px solid #3BB9FF");
     $("#add_activityType").css("border", "1px solid #3BB9FF");
   /* $("#fromleave").css("border", "1px solid #53C2FF ");
    $("#toleave").css("border", "1px solid #53C2FF ");
    $("#leavetype").css("border", "1px solid #53C2FF ");
    $("#reason").css("border", "1px solid #53C2FF ");*/
   
}

function removeActivityResultMessageAll()
{
   // alert("hiiii-------->");
   $("#charNum").text(" ");
   $("errorActivityUpdate").html(" ");
   document.forms["activityForm"].reset();
  
     $("#Activity_name").css("border", "1px solid #3BB9FF");
     $("#Activity_status").css("border", "1px solid #3BB9FF");
     $("#activityType").css("border", "1px solid #3BB9FF");
   // document.forms["activityAddForm"].reset(); 
    //document.forms["EduAddInfo"].reset();
    
    
}

function removeDataAfterActivityCloseOverlay()
{
    
   // alert("hiii");
    /*$("error").html(" ");
    $("EditSkillOverlayResult").html(" ");
    $("addSkillOverlayResult").html(" ");
    $("errorEduUpdate").html(" ");
    $("errorEduAdd").html(" ");*/
    $("#charNum").text(" ");
    $("errorActivityUpdate").html(" ");
    document.forms["activityAddForm"].reset();
     $("errorActivityUpdate").html("");
     $("#Activity_name").css("border", "1px solid #3BB9FF");
     $("#Activity_status").css("border", "1px solid #3BB9FF");
     $("#activityType").css("border", "1px solid #3BB9FF"); 
    /*document.forms["EduAddInfo"].reset();
    $("#charNum").text(" ");*/
    
}

function checkCharacters(id){
    
//alert("hii");
$(id).keyup(function(){
    el = $(this);
    if(el.val().length >= 200){
        el.val( el.val().substr(0, 200) );
    } else {
        $("#charNum").text(200-el.val().length+' Characters remaining . ');
    }
    if(el.val().length==200)
        {
        $("#charNum").text(' Cannot enter  more than 200 Characters .');    
        }
        
})
return false;
};
function addActivityValidate(){
    var activityName=$("#add_Activity_name").val();
    var activityStatus=$("#add_Activity_status").val();
    var activityType=$("#add_activityType").val();
    
    if(activityName=="" || activityName==null){
        $("errorActivityUpdate").html(" <b><font color='red'>Activity Name is Required</font></b>.");
        $("#activityName").css("border", "1px solid red");
       $("#add_Activity_name").css("border", "1px solid red");
        return false;
    }
//    if(activityStatus=="" || activityStatus==null){
//        $("errorActivityUpdate").html(" <b><font color='red'>Activity Status is Required</font></b>.");
//        $("#activityStatus").css("border", "1px solid red");
//        $("#add_Activity_status").css("border", "1px solid red");
//        return false;
//    }
    
    if(activityType=="" || activityType==null){
        $("errorActivityUpdate").html(" <b><font color='red'>Activity Type is Required</font></b>.");
        $("#activityType").css("border", "1px solid red");
       $("#add_activityType").css("border", "1px solid red");
        return false;
    }
    else
    {
        $("errorActivityUpdate").html("");
        $("#add_Activity_name").css("border", "1px solid #3BB9FF");
        $("#add_Activity_status").css("border", "1px solid #3BB9FF");
        $("#add_activityType").css("border", "1px solid #3BB9FF");
        /*$("#activityDesc").css("border", "1px solid #3BB9FF");
        $("#activityComments").css("border", "1px solid #3BB9FF");
        /*$("#edu_institution").css("border", "1px solid #3BB9FF");
        $("#val_year_start").css("border", "1px solid #3BB9FF");
        $("#edu_start_year").css("border", "1px solid #3BB9FF");
        $("#val_year_end").css("border", "1px solid #3BB9FF");
        $("#edu_end_year").css("border", "1px solid #3BB9FF");
        $("#val_percentage").css("border", "1px solid #3BB9FF");
        $("#edu_percentage").css("border", "1px solid #3BB9FF");*/
        return true;
    }
}
function editActivityValidate(){
   
   
    // var skill_rate=document.getElementById("skill_rate").value;
    
    var activityId=$("#Activity_Id").val();
    var activityName=$("#Activity_name").val();
    var activityStatus=$("#Activity_status").val();
    var activityType=$("#activityType").val();
    var activityDesc=$("#Activity_desc").val();
    var activityComments=$("#Activity_comments").val();
    /*var val_qualification= $("#edu_qualification").val();
    var val_university= $("#edu_university").val();
    var val_institution=$("#edu_institution").val();
    var val_year_start= $("#edu_start_year").val();
    var val_year_end= $("#edu_end_year").val();
    var val_percentage=$("#edu_percentage").val();
    var editStartDate = Date.parse(val_year_start);
    var editEndDate = Date.parse(val_year_end);*/
  
    
   if(activityName=="" || activityName==null){
        $("errorActivityUpdate").html(" <b><font color='red'>Activity Name is Required</font></b>.");
        $("#activityName").css("border", "1px solid red");
       $("#Activity_name").css("border", "1px solid red");
        return false;
    }
    if(activityStatus=="" || activityStatus==null){
        $("errorActivityUpdate").html(" <b><font color='red'>Activity Status is Required</font></b>.");
        $("#activityStatus").css("border", "1px solid red");
        $("#Activity_status").css("border", "1px solid red");
        return false;
    }
    
    if(activityType=="" || activityType==null){
        $("errorActivityUpdate").html(" <b><font color='red'>Activity Type is Required</font></b>.");
        $("#activityType").css("border", "1px solid red");
       $("#activityType").css("border", "1px solid red");
        return false;
    }
   /* if(activityDesc=="" || activityDesc==null){
        $("errorActivityUpdate").html(" <b><font color='red'>start year is Required</font></b>.");
        $("#activityDesc").css("border", "1px solid red");
        $("#activityDesc").css("border","1px solid red");
        return false;
    }
    if(activityComments=="" || activityComments==null){
        $("errorActivityUpdate").html(" <b><font color='red'>End year is Required</font></b>.");
        $("#activityComments").css("border", "1px solid red");
        $("#activityComments").css("border","1px solid red");
        return false;
    }
    /*if(val_percentage<1 || val_percentage>100 || val_percentage=="" ) {
      
        $("errorEduUpdate").html(" <b><font color='red'>Percentage must be between 1 to 100</font></b>.");
        $("#val_percentage").css("border", "1px solid red");
        $("#edu_percentage").css("border","1px solid red");
        return false;
    
    }
    var difference = (editEndDate - editStartDate) / (86400000 * 7);
    if (difference < 0) {
        alert("The start date must come before the end date.");
        $("errorEduUpdate").html(" <b><font color='red'>start year must be less than end year</font></b>.");
        $("#edu_start_year").css("border","1px solid red");
        $("#edu_end_year").css("border","1px solid red");
        return false;
    }*/
    else
    {
        $("errorActivityUpdate").html("");
        $("#Activity_name").css("border", "1px solid #3BB9FF");
        $("#Activity_status").css("border", "1px solid #3BB9FF");
        $("#activityType").css("border", "1px solid #3BB9FF");
        /*$("#activityDesc").css("border", "1px solid #3BB9FF");
        $("#activityComments").css("border", "1px solid #3BB9FF");
        /*$("#edu_institution").css("border", "1px solid #3BB9FF");
        $("#val_year_start").css("border", "1px solid #3BB9FF");
        $("#edu_start_year").css("border", "1px solid #3BB9FF");
        $("#val_year_end").css("border", "1px solid #3BB9FF");
        $("#edu_end_year").css("border", "1px solid #3BB9FF");
        $("#val_percentage").css("border", "1px solid #3BB9FF");
        $("#edu_percentage").css("border", "1px solid #3BB9FF");*/
        return true;
    }
       
}

function attachPopJs(){
    //alert("hii");
    var specialBox = document.getElementById('taskAttachOverlay');
    if(specialBox.style.display == "block"){       
        specialBox.style.display = "none";         
    } else {
        specialBox.style.display = "block";      
    }
    // Initialize the plugin    
    $('#consultAttachment_popup').popup(      
        );
    return false;
}
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function consult_Pager(tableName, itemsPerPage) {
    this.tableName = tableName;
    this.itemsPerPage = itemsPerPage;
    this.currentPage = 1;
    this.pages = 0;
    this.inited = false;
    
    this.showRecords = function(from, to) {        
        var rows = document.getElementById(tableName).rows;
        // i starts from 1 to skip table header row
        for (var i = 1; i < rows.length; i++) {
            if (i < from || i > to)  
                rows[i].style.display = 'none';
            else
                rows[i].style.display = '';
        }
    }
    
    this.showPage = function(pageNumber) {
        if (! this.inited) {
           // alert("not inited");
            return;
        }

        var oldPageAnchor = document.getElementById('pg'+this.currentPage);
        oldPageAnchor.className = 'pg-normal';
        
        this.currentPage = pageNumber;
        var newPageAnchor = document.getElementById('pg'+this.currentPage);
        newPageAnchor.className = 'pg-selected';
        
        var from = (pageNumber - 1) * itemsPerPage + 1;
        var to = from + itemsPerPage - 1;
        this.showRecords(from, to);
    }   
    
    this.prev = function() {
        if (this.currentPage > 1)
            this.showPage(this.currentPage - 1);
    }
    
    this.next = function() {
        if (this.currentPage < this.pages) {
            this.showPage(this.currentPage + 1);
        }
    }                        
    
    this.init = function() {
        var rows = document.getElementById(tableName).rows;
        var records = (rows.length -1); 
        this.pages = Math.ceil(records / itemsPerPage);
        this.inited = true;
    }

    this.showPageNav = function(pagerName, positionId) {
        if (! this.inited) {
            //alert("not inited");
            return;
        }
        alert(positionId)
        alert(pagerName)
        var element = document.getElementById(positionId);                                                                                  
        var pagerHtml = '<span onclick="' + pagerName + '.prev();" class="pg-normal" "> <font align="bottom" class="jumpbar"> Page: <img src="../../includes/images/jumpbar_prev.gif" border="0" alt="l"> </span> ';
        for (var page = 1; page <= this.pages; page++) 
            pagerHtml += '<span id="pg' + page + '" class="pg-normal" onclick="' + pagerName + '.showPage(' + page + ');" "><font color="black" face="verdana">' + page + '</font></span> ';
        pagerHtml += '<span onclick="'+pagerName+'.next();" class="pg-normal"> <img src="../../includes/images/jumpbar_next.gif" border="0" ></span></font>';            
        
        // pagerHtml='<span style="margin-right:40vw;>'+pagerHtml+'</span>';
        element.innerHTML =pagerHtml ;
    }
}


// DBGrid.js file start



function doNavigate(pstrWhere, pintTot)
{
  var strTmp;
  var intPg; 
  
  strTmp = document.frmDBGrid.txtCurr.value;
  intPg = parseInt(strTmp);
  if (isNaN(intPg)) intPg = 1; 
  if ((pstrWhere == 'F' || pstrWhere == 'P') && intPg == 1)
  {
    alert("You are already viewing first page!");
    return;
  }
  else if ((pstrWhere == 'N' || pstrWhere == 'L') && intPg == pintTot)
  {
    alert("You are already viewing last page!");
    return;
  }
  if (pstrWhere == 'F')
    intPg = 1;
  else if (pstrWhere == 'P')
    intPg = intPg - 1;
  else if (pstrWhere == 'N')
    intPg = intPg +1;
  else if (pstrWhere == 'L')
    intPg = pintTot; 
  if (intPg < 1) intPg = 1;
  if (intPg > pintTot) intPg = pintTot;
  document.frmDBGrid.txtCurr.value = intPg;
  document.frmDBGrid.submit();
}
function doSort(pstrFld, pstrOrd)
{
  document.frmDBGrid.txtSortCol.value = pstrFld;
  document.frmDBGrid.txtSortAsc.value = pstrOrd;
  document.frmDBGrid.submit();
}

function goToPage(element) {
    document.frmDBGrid.txtCurr.value = element.options[element.selectedIndex].value;
    document.frmDBGrid.submit();
}
function goToMyPage(element) {
    if (element == null || element.value == null 
    		|| element.value == ''){
    	return;
    }
	document.frmDBGrid.txtCurr.value = element.value;
	document.frmDBGrid.submit();
}

//responsive_tables.js start 


