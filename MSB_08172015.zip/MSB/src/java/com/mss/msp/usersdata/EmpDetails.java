/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 * created by praveen<pkatru@miraclesoft.com>
 * 
 * Date:03/10/2015
 */
package com.mss.msp.usersdata;

import java.util.Map;

/**
 *
 * @author MIRACLE
 */
public class EmpDetails {

    private String first_name;
    private String last_name;
    private String alias;
    private String phone1;
    private String marital_status;
    private String dob;
    private String gender;
    private String working_country;
    private String living_country;
    private String image_path;
    private String corp_phone;
    private String fax;
    private String email1;
    private String email2;
    private String current_status;
    private String account_name;
    private String is_team_lead;
    private String is_manager;
    private String is_pmo;
    private String is_sbteam;
    private String opt_contact;
    private int department;
    private int title;
    private Map titles;
    private String emp_position;
    private int orgid;

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getPhone1() {
        return phone1;
    }

    public void setPhone1(String phone1) {
        this.phone1 = phone1;
    }

    public String getMarital_status() {
        return marital_status;
    }

    public void setMarital_status(String marital_status) {
        this.marital_status = marital_status;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getWorking_country() {
        return working_country;
    }

    public void setWorking_country(String working_country) {
        this.working_country = working_country;
    }

    public String getLiving_country() {
        return living_country;
    }

    public void setLiving_country(String living_country) {
        this.living_country = living_country;
    }

    public String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

    public String getCorp_phone() {
        return corp_phone;
    }

    public void setCorp_phone(String corp_phone) {
        this.corp_phone = corp_phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getEmail1() {
        return email1;
    }

    public void setEmail1(String email1) {
        this.email1 = email1;
    }

    public String getEmail2() {
        return email2;
    }

    public void setEmail2(String email2) {
        this.email2 = email2;
    }

    public String getCurrent_status() {
        return current_status;
    }

    public void setCurrent_status(String current_status) {
        this.current_status = current_status;
    }

    public String getAccount_name() {
        return account_name;
    }

    public void setAccount_name(String account_name) {
        this.account_name = account_name;
    }

    public String getIs_team_lead() {
        return is_team_lead;
    }

    public void setIs_team_lead(String is_team_lead) {
        this.is_team_lead = is_team_lead;
    }

    public String getIs_manager() {
        return is_manager;
    }

    public void setIs_manager(String is_manager) {
        this.is_manager = is_manager;
    }

    public String getIs_pmo() {
        return is_pmo;
    }

    public void setIs_pmo(String is_pmo) {
        this.is_pmo = is_pmo;
    }

    public String getIs_sbteam() {
        return is_sbteam;
    }

    public void setIs_sbteam(String is_sbteam) {
        this.is_sbteam = is_sbteam;
    }

    public String getOpt_contact() {
        return opt_contact;
    }

    public void setOpt_contact(String opt_contact) {
        this.opt_contact = opt_contact;
    }

    public int getDepartment() {
        return department;
    }

    public void setDepartment(int department) {
        this.department = department;
    }

    public int getTitle() {
        return title;
    }

    public void setTitle(int title) {
        this.title = title;
    }

    public Map getTitles() {
        return titles;
    }

    public void setTitles(Map titles) {
        this.titles = titles;
    }

    public String getEmp_position() {
        return emp_position;
    }

    public void setEmp_position(String emp_position) {
        this.emp_position = emp_position;
    }

    public int getOrgid() {
        return orgid;
    }

    public void setOrgid(int orgid) {
        this.orgid = orgid;
    }
    
}
