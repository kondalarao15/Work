/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss.msp.usersdata;

/**
 *
 * @author MIRACLE
 */
public class UserAddress {
    
    //address for permanent address
    private String p_address;
    private String p_city;
    private String p_state;
    private String p_zip;
    private String p_country;
    private String p_phone;
    private String p_address2;
    //address for current address 
    private String c_address;
    private String c_city;
    private String c_state;
    private String c_zip;
    private String c_country;
    private String c_phone;
    private String c_address2;
    //address flag
    private String address_flag;

    public String getP_address() {
        return p_address;
    }

    public void setP_address(String p_address) {
        this.p_address = p_address;
    }

    public String getP_city() {
        return p_city;
    }

    public void setP_city(String p_city) {
        this.p_city = p_city;
    }

    public String getP_state() {
        return p_state;
    }

    public void setP_state(String p_state) {
        this.p_state = p_state;
    }

    public String getP_zip() {
        return p_zip;
    }

    public void setP_zip(String p_zip) {
        this.p_zip = p_zip;
    }

    public String getP_country() {
        return p_country;
    }

    public void setP_country(String p_country) {
        this.p_country = p_country;
    }

    public String getP_phone() {
        return p_phone;
    }

    public void setP_phone(String p_phone) {
        this.p_phone = p_phone;
    }

    public String getP_address2() {
        return p_address2;
    }

    public void setP_address2(String p_address2) {
        this.p_address2 = p_address2;
    }

    public String getC_address() {
        return c_address;
    }

    public void setC_address(String c_address) {
        this.c_address = c_address;
    }

    public String getC_city() {
        return c_city;
    }

    public void setC_city(String c_city) {
        this.c_city = c_city;
    }

    public String getC_state() {
        return c_state;
    }

    public void setC_state(String c_state) {
        this.c_state = c_state;
    }

    public String getC_zip() {
        return c_zip;
    }

    public void setC_zip(String c_zip) {
        this.c_zip = c_zip;
    }

    public String getC_country() {
        return c_country;
    }

    public void setC_country(String c_country) {
        this.c_country = c_country;
    }

    public String getC_phone() {
        return c_phone;
    }

    public void setC_phone(String c_phone) {
        this.c_phone = c_phone;
    }

    public String getC_address2() {
        return c_address2;
    }

    public void setC_address2(String c_address2) {
        this.c_address2 = c_address2;
    }

    public String getAddress_flag() {
        return address_flag;
    }

    public void setAddress_flag(String address_flag) {
        this.address_flag = address_flag;
    }
 
    
}
