/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss.msp.invoice;

/**
 *
 * @author miracle
 */
public class InvoiceVTO {

    private String userName;
    private String custName;
    private String invoiceDate;
    private String totalHrs;
    private String totalAmt;
    private String status;
    private int invoiceId;
    private int invoicemonth;
    private int invoiceyear;
    private int frm_orgId;
    private String frmOrgName;
    private int custOrgId;
    private String custOrgName;
    private int netTerms;
    private String payType;
    private String cheOrTransno;
    private String paymentDate;
    private double balanceAmt;
    private String description;
    private int custAppRId;
    private String custApprName;
    private String custApprDate;
    private double paidAmt;
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getTotalHrs() {
        return totalHrs;
    }

    public void setTotalHrs(String totalHrs) {
        this.totalHrs = totalHrs;
    }

    public String getTotalAmt() {
        return totalAmt;
    }

    public void setTotalAmt(String totalAmt) {
        this.totalAmt = totalAmt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(int invoiceId) {
        this.invoiceId = invoiceId;
    }

    public int getInvoiceyear() {
        return invoiceyear;
    }

    public void setInvoiceyear(int invoiceyear) {
        this.invoiceyear = invoiceyear;
    }

    public int getFrm_orgId() {
        return frm_orgId;
    }

    public void setFrm_orgId(int frm_orgId) {
        this.frm_orgId = frm_orgId;
    }

    public String getFrmOrgName() {
        return frmOrgName;
    }

    public void setFrmOrgName(String frmOrgName) {
        this.frmOrgName = frmOrgName;
    }

    public int getCustOrgId() {
        return custOrgId;
    }

    public void setCustOrgId(int custOrgId) {
        this.custOrgId = custOrgId;
    }

    public String getCustOrgName() {
        return custOrgName;
    }

    public void setCustOrgName(String custOrgName) {
        this.custOrgName = custOrgName;
    }

    public int getNetTerms() {
        return netTerms;
    }

    public void setNetTerms(int netTerms) {
        this.netTerms = netTerms;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getCheOrTransno() {
        return cheOrTransno;
    }

    public void setCheOrTransno(String cheOrTransno) {
        this.cheOrTransno = cheOrTransno;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public double getBalanceAmt() {
        return balanceAmt;
    }

    public void setBalanceAmt(double balanceAmt) {
        this.balanceAmt = balanceAmt;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getCustAppRId() {
        return custAppRId;
    }

    public void setCustAppRId(int custAppRId) {
        this.custAppRId = custAppRId;
    }

    public String getCustApprDate() {
        return custApprDate;
    }

    public void setCustApprDate(String custApprDate) {
        this.custApprDate = custApprDate;
    }

    public int getInvoicemonth() {
        return invoicemonth;
    }

    public void setInvoicemonth(int invoicemonth) {
        this.invoicemonth = invoicemonth;
    }

    public String getCustApprName() {
        return custApprName;
    }

    public void setCustApprName(String custApprName) {
        this.custApprName = custApprName;
    }

    public double getPaidAmt() {
        return paidAmt;
    }

    public void setPaidAmt(double paidAmt) {
        this.paidAmt = paidAmt;
    }
    
}
