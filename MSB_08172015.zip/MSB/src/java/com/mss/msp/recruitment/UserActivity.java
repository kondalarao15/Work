/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mss.msp.recruitment;



/**
 *
 * @author miracle
 */
public class UserActivity {
    private int activityId;
    private int objectID;
    private String objectType;
    private String activityType;
    private String activityPriority;
    private String activityName;
    private String activityRelation;
    private String activityStatus;
    private String activityComments;
    private String activityDesc;
    private String activityCratedDate;
    private String activityCratedBy;
    private int consult_orgid;

    public int getActivityId() {
        return activityId;
    }

    public void setActivityId(int activityId) {
        this.activityId = activityId;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityPriority() {
        return activityPriority;
    }

    public void setActivityPriority(String activityPriority) {
        this.activityPriority = activityPriority;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getActivityStatus() {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus) {
        this.activityStatus = activityStatus;
    }

    public String getActivityComments() {
        return activityComments;
    }

    public void setActivityComments(String activityComments) {
        this.activityComments = activityComments;
    }

    public String getActivityDesc() {
        return activityDesc;
    }

    public void setActivityDesc(String activityDesc) {
        this.activityDesc = activityDesc;
    }

    public String getActivityCratedDate() {
        return activityCratedDate;
    }

    public void setActivityCratedDate(String activityCratedDate) {
        this.activityCratedDate = activityCratedDate;
    }

    public String getActivityCratedBy() {
        return activityCratedBy;
    }

    public void setActivityCratedBy(String activityCratedBy) {
        this.activityCratedBy = activityCratedBy;
    }

    public int getConsult_orgid() {
        return consult_orgid;
    }

    public void setConsult_orgid(int consult_orgid) {
        this.consult_orgid = consult_orgid;
    }

    public String getActivityRelation() {
        return activityRelation;
    }

    public void setActivityRelation(String activityRelation) {
        this.activityRelation = activityRelation;
    }

    public int getObjectID() {
        return objectID;
    }

    public void setObjectID(int objectID) {
        this.objectID = objectID;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }
}
